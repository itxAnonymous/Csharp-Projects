// cafe(order) management system.cpp 


#include<iostream>
#include<conio.h>
using namespace std;
class start                            //base class
{
protected:
	char name[30];                        //customer name
public:
	void info()                          //information function
	{
		cout << "\t\t\t----------CAFETERIA ORDER MANAGEMENT SYSTEM-----------\n\n";
		cout << "\nPlease Enter Your Name: ";
		cin >> name;                           //input name of customer
	}
};
class order :public start            //drive class
{
protected:

	char gotostart;                                 //for option 
	int choice, pchoice, pchoice1, quantity;         //for item choice and quantity
public:
	void orrder()                                  //taking order
	{
		start::info();                                //call info function
		choice = 0;
	beginning:                                   //go to start=y

		cout << "\t\t\tHello " << name << "\n\nWhat would you like to order?\n\n";

		cout << "\t\t\t\t--------Menu--------\n\n";

		cout << "\t\t\t1) Pizzas\n";
		cout << "\t\t\t2) Burgers\n";
		cout << "\t\t\t3) Sandwich\n";
		cout << "\t\t\t4) Rolls\n";
		cout << "\t\t\t5) Biryani\n\n";
		cout << "\nPlease Enter your Choice: ";
		cin >> choice;                          // input items

		if (choice == 1)                        //if condition for first choice of item
		{
			cout << "\n\n\n\t\t\t1) " << "Chicken Fazita\n";
			cout << "\t\t\t2) " << "Chicken Bar BQ\n";
			cout << "\t\t\t3) " << "Peri Peri\n";
			cout << "\t\t\t4) " << "Creamy Max\n";
			cout << "\n\nPlease Enter which Flavour would you like to have?:";
			cin >> pchoice;                      //selection of flavour
			if (pchoice >= 1 && pchoice <= 5)      //if condition use for choice material or item size
			{
				cout << "\n\t\t\t1) Small Rs.250\n" << "\t\t\t2) Regular Rs.500\n" << "\t\t\t3) Large Rs.900\n";
				cout << "\nChoose Size Please:";
				cin >> pchoice1;                    //selection of size
				if (pchoice1 >= 1 && pchoice1 <= 3)    //if condition for choising quantity
					cout << "\nPlease Enter Quantity: ";
				cin >> quantity;                      //selection of quantity
				switch (pchoice1)                   //switch statement for choice of different quantity
				{
				case 1: choice = 250 * quantity;
					break;

				case 2: choice = 500 * quantity;
					break;

				case 3: choice = 900 * quantity;
					break;


				}

				switch (pchoice1)                //switch for display the selected items
				{
				case 1:
					cout << "\n\n\t\t\t--------Your Order---------\n\n";
					cout << "\n\n\t\t\tNAME : " << name << endl;
					cout << "\t\t\t" << quantity << "  chicken fazita" << endl;
					cout << "\t\t\tYour Total Bill is" << choice << "\n\n\nYour Order Will be delivered in 10 Minutes" << endl;
					cout << "\n\n\t\t\tThank you For Ordering \n\n\n";
					break;
				case 2:
					cout << "\n\n\t\t--------Your Order---------\n";
					cout << "\n\n\t\t\tNAME : " << name << endl;
					cout << "\t\t\t" << quantity << "   chicken Bar BQ" << endl;
					cout << "\n\t\t\tYour Total Bill is " << choice << "\n\n\nYour Order Will be delivered in 10 Minutes" << endl;
					cout << "\n\t\t\tThank you For Ordering \n";
					break;
				case 3:
					cout << "\n\n\t\t--------Your Order---------\n";
					cout << "\n\n\t\t\tNAME : " << name << endl;
					cout << "\t\t\t" << quantity << "  peeri peeri" << endl;
					cout << "\n\t\t\tYour Total Bill is" << choice << "\n\n\nYour Order Will be delivered in 10 Minutes" << endl;
					cout << "\n\t\t\tThank you For Ordering \n";
					break;
				case 4:
					cout << "\n\n\t\t--------Your Order---------\n";
					cout << "\n\n\t\t\tNAME : " << name << endl;
					cout << "\t\t\t" << quantity << "  creamy mix" << endl;
					cout << "\n\t\t\tYour Total Bill is" << choice << "\n\n\nYour Order Will be delivered in 10 Minutes" << endl;
					cout << "\n\t\t\tThank you For Ordering \n";
					break;

				}
				cout << "Would you like to order anything else? Y / N:";
				cin >> gotostart;                            //curser return to starting of menu
				if (gotostart == 'Y' || gotostart == 'y')      //this condition for gotostart menu with y
				{
					goto beginning;                         //cursor will reach on starting point
					//return 0;
				}



			}

		}


		else if (choice == 2)                      //elseif for 2nd choice of item
		{
			cout << "\n\t\t\t1  zinger burger Rs.180" << "\n";
			cout << "\t\t\t2  chicken burger Rs.150" << "\n";
			cout << "\t\t\t3  beef burger Rs.160" << "\n";
			cout << "\nPlease Enter which Burger you would like to have?: ";
			cin >> pchoice1;                      //selection of flavour
			if (pchoice1 >= 1 && pchoice1 <= 3)     //if condition use for choice material or item size
			{
				cout << "\nPlease Enter Quantity: ";
				cin >> quantity;                     //selection of quantity
				switch (pchoice1)                  //switch statement for choice of different quantity
				{
				case 1: choice = 180 * quantity;
					break;

				case 2: choice = 150 * quantity;
					break;

				case 3: choice = 160 * quantity;
					break;

				}

				switch (pchoice1)             //switch for display the selected items
				{
				case 1:
					cout << "\n\n\t\t--------Your Order---------\n";
					cout << "\n\n\t\t\tNAME : " << name << endl;
					cout << "\t\t\t" << quantity << "  zinger burger" << endl;
					cout << "\n\t\t\tYour Total Bill is" << choice << "\n\n\nYour Order Will be delivered in 10 Minutes" << endl;
					cout << "\n\t\t\tThank you For Ordering \n";
					break;
				case 2:
					cout << "\n\n\t\t--------Your Order---------\n";
					cout << "\n\n\t\t\tNAME : " << name << endl;
					cout << "\t\t\t" << quantity << "   chicken burger" << endl;
					cout << "\n\t\t\tYour Total Bill is" << choice << "\n\n\nYour Order Will be delivered in 10 Minutes" << endl;
					cout << "\n\t\t\tThank you For Ordering \n";
					break;
				case 3:
					cout << "\n\n\t\t--------Your Order---------\n";
					cout << "\n\n\t\t\tNAME : " << name << endl;
					cout << "\t\t\t" << quantity << "  beef burger" << endl;
					cout << "\n\t\t\tYour Total Bill is" << choice << "\n\n\nYour Order Will be delivered in 10 Minutes" << endl;
					cout << "\n\t\t\tThank you For Ordering\n";
					break;


				}
				cout << "\nWould you like to order anything else? Y / N:";
				cin >> gotostart;                          //curser return to starting of menu
				if (gotostart == 'Y' || gotostart == 'y')     //this condition for gotostart menu with y
				{
					goto beginning;                        //cursor will reach on starting point
					//return 0;
				}

			}
		}
		else if (choice == 3)                     //elseif for 3rd choice of item
		{
			cout << "\n\t\t\t1  club sandwich Rs.240" << "\n";
			cout << "\t\t\t2  chicken crispy sandwich Rs.160" << "\n";
			cout << "\t\t\t3  extreme veg sandwich Rs.100" << "\n";
			cout << "\nPlease Enter which Sandwich you would like to have?:";
			cin >> pchoice1;                      //selection of flavour
			if (pchoice1 >= 1 && pchoice1 <= 3)     //if condition use for choice material or item size
			{
				cout << "\nPlease Enter Quantity: ";
				cin >> quantity;                      //selection of quantity
				switch (pchoice1)                   //switch statement for choice of different quantity
				{
				case 1: choice = 240 * quantity;
					break;

				case 2: choice = 160 * quantity;
					break;

				case 3: choice = 100 * quantity;
					break;

				}

				switch (pchoice1)              //switch for display the selected items
				{
				case 1:
					cout << "\n\n\t\t--------Your Order---------\n";
					cout << "\n\n\t\t\tNAME : " << name << endl;
					cout << "\t\t\t" << quantity << " club sandwich" << endl;
					cout << "\n\t\t\tYour Total Bill is" << choice << "\n\n\nYour Order Will be delivered in 10 Minutes" << endl;
					cout << "\n\t\t\tThank you For Ordering \n";
					break;
				case 2:
					cout << "\n\n\t\t--------Your Order---------\n";
					cout << "\n\n\t\t\tNAME : " << name << endl;
					cout << "\t\t\t" << quantity << "  chicken crispy sandwich" << endl;
					cout << "\n\t\t\tYour Total Bill is" << choice << "\n\n\nYour Order Will be delivered in 10 Minutes" << endl;
					cout << "\n\t\t\tThank you For Ordering \n";
					break;
				case 3:
					cout << "\n\n\t\t--------Your Order---------\n";
					cout << "\n\n\t\t\tNAME : " << name << endl;
					cout << "\t\t\t" << quantity << " extreme veg sandwich" << endl;
					cout << "\n\t\t\tYour Total Bill is" << choice << "\n\n\nYour Order Will be delivered in 10 Minutes" << endl;
					cout << "\n\t\t\tThank you For Ordering \n";
					break;


				}
				cout << "Would you like to order anything else? Y / N:";
				cin >> gotostart;                          //curser return to starting of menu
				if (gotostart == 'Y' || gotostart == 'y')    //this condition for go to start menu with y
				{
					goto beginning;                        //cursor will reach on starting point
					//return 0;
				}
			}
		}


		else if (choice == 4)                      //elseif for 4th choice of item
		{
			cout << "\n\t\t\t1 chicken chatni roll Rs.150" << "\n";
			cout << "\t\t\t2 chicken mayo roll Rs.100" << "\n";
			cout << "\t\t\t3 veg roll with fries Rs.120" << "\n";
			cout << "\nPlease Enter which you would like to have?: ";
			cin >> pchoice1;                                                              //selection of flavour
			if (pchoice1 >= 1 && pchoice1 <= 3)     //if condition use for choice material or item size
			{
				cout << "\nHow Much Rolls Do you want: ";
				cin >> quantity;                     //selection of quantity
				switch (pchoice1)                  //switch statement for choice of different quantity        
				{
				case 1: choice = 150 * quantity;
					break;

				case 2: choice = 100 * quantity;
					break;

				case 3: choice = 120 * quantity;
					break;

				}

				switch (pchoice1)               //switch for display the selected items
				{
				case 1:
					cout << "\n\n\t\t--------Your Order---------\n";
					cout << "\n\n\t\t\tNAME : " << name << endl;
					cout << "\t\t\t" << quantity << "  chicken chatni roll" << endl;
					cout << "\n\t\t\tYour Total Bill is" << choice << "\n\n\nYour Order Will be delivered in 10 Minutes" << endl;
					cout << "\n\t\t\tThank you For Ordering \n";
					break;
				case 2:
					cout << "\n\n\t\t--------Your Order---------\n";
					cout << "\n\n\t\t\tNAME : " << name << endl;
					cout << "\t\t\t" << quantity << "   chicken mayo roll" << endl;
					cout << "\n\t\t\tYour Total Bill is" << choice << "\n\n\nYour Order Will be delivered in 10 Minutes" << endl;
					cout << "\n\t\t\tThank you For Ordering \n";
					break;
				case 3:
					cout << "\n\n\t\t--------Your Order---------\n";
					cout << "\n\n\t\t\tNAME : " << name << endl;
					cout << "\t\t\t" << quantity << "  veg roll with fries" << endl;
					cout << "\n\t\t\tYour Total Bill is" << choice << "\n\n\nYour Order Will be delivered in 10 Minutes" << endl;
					cout << "\n\t\t\tThank you For Ordering \n";
					break;


				}

			}
		}
		else if (choice == 5)                     //else statement for fifth choice
		{
			cout << "\n\t\t\t1 chicken biryani Rs.160" << "\n";
			cout << "\t\t\t2 pawn biryani Rs.220" << "\n";
			cout << "\t\t\t3 beef biryani Rs.140" << "\n";
			cout << "\nPlease Enter which Biryani you would like to have?:";
			cin >> pchoice1;                      //selection of flavour
			if (pchoice1 >= 1 && pchoice1 <= 3)     //if condition use for choice material or item size
			{
				cout << "\nPlease Enter Quantity: ";
				cin >> quantity;                     //selection of quantity
				switch (pchoice1)                  //switch statement for choice of different quantity                                  
				{
				case 1: choice = 160 * quantity;
					break;

				case 2: choice = 220 * quantity;
					break;

				case 3: choice = 140 * quantity;
					break;

				}
				switch (pchoice1)            //switch for display the selected items
				{
				case 1:
					cout << "\n\n\t\t--------Your Order---------\n";
					cout << "\n\n\t\t\tNAME : " << name << endl;
					cout << "\t\t\t" << quantity << "  chicken biryani" << endl;
					cout << "\n\t\t\tYour Total Bill is" << choice << "\n\n\nYour Order Will be delivered in 10 Minutes" << endl;
					cout << "\n\t\t\tThank you For Ordering  \n";
					break;
				case 2:
					cout << "\n\n\t\t--------Your Order---------\n";
					cout << "\n\n\t\t\tNAME : " << name << endl;
					cout << "\t\t\t" << quantity << "   pawn biryani" << endl;
					cout << "\n\t\t\tYour Total Bill is" << choice << "\n\n\nYour Order Will be delivered in 10 Minutes" << endl;
					cout << "\n\t\t\tThank you For Ordering \n";
					break;
				case 3:
					cout << "\n\n\t\t--------Your Order---------\n";
					cout << "\n\n\t\t\tNAME : " << name << endl;
					cout << "\t\t\t" << quantity << "  beef biryani" << endl;
					cout << "\n\t\t\tYour Total Bill is" << choice << "\n\n\nYour Order Will be delivered in 10 Minutes" << endl;
					cout << "\n\t\t\tThank you For Ordering \n";
					break;


				}
				cout << "Would you like to order anything else? Y / N:";
				cin >> gotostart;                                                                //curser return to starting of menu
				if (gotostart == 'Y' || gotostart == 'y')      //this condition for gotostart menu with y
				{
					goto beginning;                          //cursor will reach on starting point
					//return 0;
				}
			}
		}

		else
		{
			system("CLS");
			cout << "Please Select Right Option: \n";
			cout << "Would You like to Start the program again? Y / N: ";
			cin >> gotostart;                        //curser return to starting of menu

			if (gotostart == 'Y' || gotostart == 'y')   //this condition for gotostart menu with y
			{
				goto beginning;                      //cursor will reach on starting point
				//return 0;
			}
		}
	}
};
int main()            //main body
{
	order o;                                        //create object of order
	o.orrder();                                     //display the value

}
