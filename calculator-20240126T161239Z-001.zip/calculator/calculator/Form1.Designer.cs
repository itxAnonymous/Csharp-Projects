﻿namespace calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.roundedButtonequal = new RoundedButton();
            this.roundedButtonaddition = new RoundedButton();
            this.roundedButtonsubtraction = new RoundedButton();
            this.roundedButtonmultiplication = new RoundedButton();
            this.roundedButtondivision = new RoundedButton();
            this.roundedButtoncut = new RoundedButton();
            this.roundedButtonthree = new RoundedButton();
            this.roundedButtonsix = new RoundedButton();
            this.roundedButtonnine = new RoundedButton();
            this.roundedButtonpercent = new RoundedButton();
            this.roundedButtondot = new RoundedButton();
            this.roundedButtontwo = new RoundedButton();
            this.roundedButtonfive = new RoundedButton();
            this.roundedButtoneight = new RoundedButton();
            this.roundedButton10 = new RoundedButton();
            this.roundedButtonzero = new RoundedButton();
            this.roundedButtonone = new RoundedButton();
            this.roundedButtonfour = new RoundedButton();
            this.roundedButtonseven = new RoundedButton();
            this.roundedButtonAC = new RoundedButton();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(149)))), ((int)(((byte)(125)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.SystemColors.Window;
            this.textBox1.Location = new System.Drawing.Point(0, 0);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(315, 132);
            this.textBox1.TabIndex = 0;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // roundedButtonequal
            // 
            this.roundedButtonequal.BackColor = System.Drawing.Color.Sienna;
            this.roundedButtonequal.BorderRadius = 34;
            this.roundedButtonequal.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundedButtonequal.Location = new System.Drawing.Point(237, 424);
            this.roundedButtonequal.Name = "roundedButtonequal";
            this.roundedButtonequal.Size = new System.Drawing.Size(68, 62);
            this.roundedButtonequal.TabIndex = 40;
            this.roundedButtonequal.Text = "=";
            this.roundedButtonequal.TextColor = System.Drawing.Color.White;
            this.roundedButtonequal.UseVisualStyleBackColor = false;
            this.roundedButtonequal.Click += new System.EventHandler(this.roundedButtonequal_Click);
            // 
            // roundedButtonaddition
            // 
            this.roundedButtonaddition.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(129)))), ((int)(((byte)(112)))));
            this.roundedButtonaddition.BorderRadius = 34;
            this.roundedButtonaddition.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundedButtonaddition.Location = new System.Drawing.Point(237, 356);
            this.roundedButtonaddition.Name = "roundedButtonaddition";
            this.roundedButtonaddition.Size = new System.Drawing.Size(68, 62);
            this.roundedButtonaddition.TabIndex = 39;
            this.roundedButtonaddition.Text = "+";
            this.roundedButtonaddition.TextColor = System.Drawing.Color.White;
            this.roundedButtonaddition.UseVisualStyleBackColor = false;
            this.roundedButtonaddition.Click += new System.EventHandler(this.roundedButtonaddition_Click);
            // 
            // roundedButtonsubtraction
            // 
            this.roundedButtonsubtraction.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(129)))), ((int)(((byte)(112)))));
            this.roundedButtonsubtraction.BorderRadius = 34;
            this.roundedButtonsubtraction.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundedButtonsubtraction.Location = new System.Drawing.Point(234, 288);
            this.roundedButtonsubtraction.Name = "roundedButtonsubtraction";
            this.roundedButtonsubtraction.Size = new System.Drawing.Size(68, 62);
            this.roundedButtonsubtraction.TabIndex = 38;
            this.roundedButtonsubtraction.Text = "-";
            this.roundedButtonsubtraction.TextColor = System.Drawing.Color.White;
            this.roundedButtonsubtraction.UseVisualStyleBackColor = false;
            this.roundedButtonsubtraction.Click += new System.EventHandler(this.roundedButtonsubtraction_Click);
            // 
            // roundedButtonmultiplication
            // 
            this.roundedButtonmultiplication.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(129)))), ((int)(((byte)(112)))));
            this.roundedButtonmultiplication.BorderRadius = 34;
            this.roundedButtonmultiplication.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundedButtonmultiplication.Location = new System.Drawing.Point(234, 220);
            this.roundedButtonmultiplication.Name = "roundedButtonmultiplication";
            this.roundedButtonmultiplication.Size = new System.Drawing.Size(68, 62);
            this.roundedButtonmultiplication.TabIndex = 37;
            this.roundedButtonmultiplication.Text = "X";
            this.roundedButtonmultiplication.TextColor = System.Drawing.Color.White;
            this.roundedButtonmultiplication.UseVisualStyleBackColor = false;
            this.roundedButtonmultiplication.Click += new System.EventHandler(this.roundedButtonmultiplication_Click);
            // 
            // roundedButtondivision
            // 
            this.roundedButtondivision.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(129)))), ((int)(((byte)(112)))));
            this.roundedButtondivision.BorderRadius = 34;
            this.roundedButtondivision.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundedButtondivision.Location = new System.Drawing.Point(234, 150);
            this.roundedButtondivision.Name = "roundedButtondivision";
            this.roundedButtondivision.Size = new System.Drawing.Size(68, 62);
            this.roundedButtondivision.TabIndex = 36;
            this.roundedButtondivision.Text = "/";
            this.roundedButtondivision.TextColor = System.Drawing.Color.White;
            this.roundedButtondivision.UseVisualStyleBackColor = false;
            this.roundedButtondivision.Click += new System.EventHandler(this.roundedButtondivision_Click);
            // 
            // roundedButtoncut
            // 
            this.roundedButtoncut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(76)))), ((int)(((byte)(76)))));
            this.roundedButtoncut.BorderRadius = 34;
            this.roundedButtoncut.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundedButtoncut.Location = new System.Drawing.Point(163, 424);
            this.roundedButtoncut.Name = "roundedButtoncut";
            this.roundedButtoncut.Size = new System.Drawing.Size(68, 62);
            this.roundedButtoncut.TabIndex = 35;
            this.roundedButtoncut.Text = "x";
            this.roundedButtoncut.TextColor = System.Drawing.Color.White;
            this.roundedButtoncut.UseVisualStyleBackColor = false;
            this.roundedButtoncut.Click += new System.EventHandler(this.roundedButtoncut_Click);
            // 
            // roundedButtonthree
            // 
            this.roundedButtonthree.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(76)))), ((int)(((byte)(76)))));
            this.roundedButtonthree.BorderRadius = 34;
            this.roundedButtonthree.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundedButtonthree.Location = new System.Drawing.Point(163, 356);
            this.roundedButtonthree.Name = "roundedButtonthree";
            this.roundedButtonthree.Size = new System.Drawing.Size(68, 62);
            this.roundedButtonthree.TabIndex = 34;
            this.roundedButtonthree.Text = "3";
            this.roundedButtonthree.TextColor = System.Drawing.Color.White;
            this.roundedButtonthree.UseVisualStyleBackColor = false;
            this.roundedButtonthree.Click += new System.EventHandler(this.roundedButtonthree_Click);
            // 
            // roundedButtonsix
            // 
            this.roundedButtonsix.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(76)))), ((int)(((byte)(76)))));
            this.roundedButtonsix.BorderRadius = 34;
            this.roundedButtonsix.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundedButtonsix.Location = new System.Drawing.Point(160, 288);
            this.roundedButtonsix.Name = "roundedButtonsix";
            this.roundedButtonsix.Size = new System.Drawing.Size(68, 62);
            this.roundedButtonsix.TabIndex = 33;
            this.roundedButtonsix.Text = "6";
            this.roundedButtonsix.TextColor = System.Drawing.Color.White;
            this.roundedButtonsix.UseVisualStyleBackColor = false;
            this.roundedButtonsix.Click += new System.EventHandler(this.roundedButtonsix_Click);
            // 
            // roundedButtonnine
            // 
            this.roundedButtonnine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(76)))), ((int)(((byte)(76)))));
            this.roundedButtonnine.BorderRadius = 34;
            this.roundedButtonnine.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundedButtonnine.Location = new System.Drawing.Point(160, 220);
            this.roundedButtonnine.Name = "roundedButtonnine";
            this.roundedButtonnine.Size = new System.Drawing.Size(68, 62);
            this.roundedButtonnine.TabIndex = 32;
            this.roundedButtonnine.Text = "9";
            this.roundedButtonnine.TextColor = System.Drawing.Color.White;
            this.roundedButtonnine.UseVisualStyleBackColor = false;
            this.roundedButtonnine.Click += new System.EventHandler(this.roundedButtonnine_Click);
            // 
            // roundedButtonpercent
            // 
            this.roundedButtonpercent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(129)))), ((int)(((byte)(112)))));
            this.roundedButtonpercent.BorderRadius = 34;
            this.roundedButtonpercent.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundedButtonpercent.Location = new System.Drawing.Point(160, 150);
            this.roundedButtonpercent.Name = "roundedButtonpercent";
            this.roundedButtonpercent.Size = new System.Drawing.Size(68, 62);
            this.roundedButtonpercent.TabIndex = 31;
            this.roundedButtonpercent.Text = "%";
            this.roundedButtonpercent.TextColor = System.Drawing.Color.White;
            this.roundedButtonpercent.UseVisualStyleBackColor = false;
            this.roundedButtonpercent.Click += new System.EventHandler(this.roundedButtonpercent_Click);
            // 
            // roundedButtondot
            // 
            this.roundedButtondot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(76)))), ((int)(((byte)(76)))));
            this.roundedButtondot.BorderRadius = 34;
            this.roundedButtondot.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundedButtondot.Location = new System.Drawing.Point(89, 424);
            this.roundedButtondot.Name = "roundedButtondot";
            this.roundedButtondot.Size = new System.Drawing.Size(68, 62);
            this.roundedButtondot.TabIndex = 30;
            this.roundedButtondot.Text = ".";
            this.roundedButtondot.TextColor = System.Drawing.Color.White;
            this.roundedButtondot.UseVisualStyleBackColor = false;
            this.roundedButtondot.Click += new System.EventHandler(this.roundedButtondot_Click);
            // 
            // roundedButtontwo
            // 
            this.roundedButtontwo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(76)))), ((int)(((byte)(76)))));
            this.roundedButtontwo.BorderRadius = 34;
            this.roundedButtontwo.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundedButtontwo.Location = new System.Drawing.Point(89, 356);
            this.roundedButtontwo.Name = "roundedButtontwo";
            this.roundedButtontwo.Size = new System.Drawing.Size(68, 62);
            this.roundedButtontwo.TabIndex = 29;
            this.roundedButtontwo.Text = "2";
            this.roundedButtontwo.TextColor = System.Drawing.Color.White;
            this.roundedButtontwo.UseVisualStyleBackColor = false;
            this.roundedButtontwo.Click += new System.EventHandler(this.roundedButtontwo_Click);
            // 
            // roundedButtonfive
            // 
            this.roundedButtonfive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(76)))), ((int)(((byte)(76)))));
            this.roundedButtonfive.BorderRadius = 34;
            this.roundedButtonfive.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundedButtonfive.Location = new System.Drawing.Point(86, 288);
            this.roundedButtonfive.Name = "roundedButtonfive";
            this.roundedButtonfive.Size = new System.Drawing.Size(68, 62);
            this.roundedButtonfive.TabIndex = 28;
            this.roundedButtonfive.Text = "5";
            this.roundedButtonfive.TextColor = System.Drawing.Color.White;
            this.roundedButtonfive.UseVisualStyleBackColor = false;
            this.roundedButtonfive.Click += new System.EventHandler(this.roundedButtonfive_Click);
            // 
            // roundedButtoneight
            // 
            this.roundedButtoneight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(76)))), ((int)(((byte)(76)))));
            this.roundedButtoneight.BorderRadius = 34;
            this.roundedButtoneight.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundedButtoneight.Location = new System.Drawing.Point(86, 220);
            this.roundedButtoneight.Name = "roundedButtoneight";
            this.roundedButtoneight.Size = new System.Drawing.Size(68, 62);
            this.roundedButtoneight.TabIndex = 27;
            this.roundedButtoneight.Text = "8";
            this.roundedButtoneight.TextColor = System.Drawing.Color.White;
            this.roundedButtoneight.UseVisualStyleBackColor = false;
            this.roundedButtoneight.Click += new System.EventHandler(this.roundedButtoneight_Click);
            // 
            // roundedButton10
            // 
            this.roundedButton10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(129)))), ((int)(((byte)(112)))));
            this.roundedButton10.BorderRadius = 34;
            this.roundedButton10.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundedButton10.Location = new System.Drawing.Point(86, 150);
            this.roundedButton10.Name = "roundedButton10";
            this.roundedButton10.Size = new System.Drawing.Size(68, 62);
            this.roundedButton10.TabIndex = 26;
            this.roundedButton10.Text = "(  )";
            this.roundedButton10.TextColor = System.Drawing.Color.White;
            this.roundedButton10.UseVisualStyleBackColor = false;
            this.roundedButton10.Click += new System.EventHandler(this.roundedButton10_Click);
            // 
            // roundedButtonzero
            // 
            this.roundedButtonzero.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(76)))), ((int)(((byte)(76)))));
            this.roundedButtonzero.BorderRadius = 34;
            this.roundedButtonzero.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundedButtonzero.Location = new System.Drawing.Point(15, 422);
            this.roundedButtonzero.Name = "roundedButtonzero";
            this.roundedButtonzero.Size = new System.Drawing.Size(68, 62);
            this.roundedButtonzero.TabIndex = 25;
            this.roundedButtonzero.Text = "0";
            this.roundedButtonzero.TextColor = System.Drawing.Color.White;
            this.roundedButtonzero.UseVisualStyleBackColor = false;
            this.roundedButtonzero.Click += new System.EventHandler(this.roundedButtonzero_Click);
            // 
            // roundedButtonone
            // 
            this.roundedButtonone.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(76)))), ((int)(((byte)(76)))));
            this.roundedButtonone.BorderRadius = 34;
            this.roundedButtonone.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundedButtonone.Location = new System.Drawing.Point(15, 354);
            this.roundedButtonone.Name = "roundedButtonone";
            this.roundedButtonone.Size = new System.Drawing.Size(68, 62);
            this.roundedButtonone.TabIndex = 24;
            this.roundedButtonone.Text = "1";
            this.roundedButtonone.TextColor = System.Drawing.Color.White;
            this.roundedButtonone.UseVisualStyleBackColor = false;
            this.roundedButtonone.Click += new System.EventHandler(this.roundedButtonone_Click);
            // 
            // roundedButtonfour
            // 
            this.roundedButtonfour.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(76)))), ((int)(((byte)(76)))));
            this.roundedButtonfour.BorderRadius = 34;
            this.roundedButtonfour.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundedButtonfour.Location = new System.Drawing.Point(12, 286);
            this.roundedButtonfour.Name = "roundedButtonfour";
            this.roundedButtonfour.Size = new System.Drawing.Size(68, 62);
            this.roundedButtonfour.TabIndex = 23;
            this.roundedButtonfour.Text = "4";
            this.roundedButtonfour.TextColor = System.Drawing.Color.White;
            this.roundedButtonfour.UseVisualStyleBackColor = false;
            this.roundedButtonfour.Click += new System.EventHandler(this.roundedButtonfour_Click);
            // 
            // roundedButtonseven
            // 
            this.roundedButtonseven.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(76)))), ((int)(((byte)(76)))));
            this.roundedButtonseven.BorderRadius = 34;
            this.roundedButtonseven.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundedButtonseven.Location = new System.Drawing.Point(12, 218);
            this.roundedButtonseven.Name = "roundedButtonseven";
            this.roundedButtonseven.Size = new System.Drawing.Size(68, 62);
            this.roundedButtonseven.TabIndex = 22;
            this.roundedButtonseven.Text = "7";
            this.roundedButtonseven.TextColor = System.Drawing.Color.White;
            this.roundedButtonseven.UseVisualStyleBackColor = false;
            this.roundedButtonseven.Click += new System.EventHandler(this.roundedButtonsevsen_Click);
            // 
            // roundedButtonAC
            // 
            this.roundedButtonAC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(181)))), ((int)(((byte)(59)))));
            this.roundedButtonAC.BorderRadius = 34;
            this.roundedButtonAC.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundedButtonAC.ForeColor = System.Drawing.Color.Black;
            this.roundedButtonAC.Location = new System.Drawing.Point(12, 148);
            this.roundedButtonAC.Name = "roundedButtonAC";
            this.roundedButtonAC.Size = new System.Drawing.Size(68, 62);
            this.roundedButtonAC.TabIndex = 21;
            this.roundedButtonAC.Text = "AC";
            this.roundedButtonAC.TextColor = System.Drawing.Color.White;
            this.roundedButtonAC.UseVisualStyleBackColor = false;
            this.roundedButtonAC.Click += new System.EventHandler(this.roundedButtonAC_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(315, 488);
            this.Controls.Add(this.roundedButtonequal);
            this.Controls.Add(this.roundedButtonaddition);
            this.Controls.Add(this.roundedButtonsubtraction);
            this.Controls.Add(this.roundedButtonmultiplication);
            this.Controls.Add(this.roundedButtondivision);
            this.Controls.Add(this.roundedButtoncut);
            this.Controls.Add(this.roundedButtonthree);
            this.Controls.Add(this.roundedButtonsix);
            this.Controls.Add(this.roundedButtonnine);
            this.Controls.Add(this.roundedButtonpercent);
            this.Controls.Add(this.roundedButtondot);
            this.Controls.Add(this.roundedButtontwo);
            this.Controls.Add(this.roundedButtonfive);
            this.Controls.Add(this.roundedButtoneight);
            this.Controls.Add(this.roundedButton10);
            this.Controls.Add(this.roundedButtonzero);
            this.Controls.Add(this.roundedButtonone);
            this.Controls.Add(this.roundedButtonfour);
            this.Controls.Add(this.roundedButtonseven);
            this.Controls.Add(this.roundedButtonAC);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private RoundedButton roundedButtonAC;
        private RoundedButton roundedButtonseven;
        private RoundedButton roundedButtonfour;
        private RoundedButton roundedButtonone;
        private RoundedButton roundedButtonzero;
        private RoundedButton roundedButtondot;
        private RoundedButton roundedButtontwo;
        private RoundedButton roundedButtonfive;
        private RoundedButton roundedButtoneight;
        private RoundedButton roundedButton10;
        private RoundedButton roundedButtoncut;
        private RoundedButton roundedButtonthree;
        private RoundedButton roundedButtonsix;
        private RoundedButton roundedButtonnine;
        private RoundedButton roundedButtonpercent;
        private RoundedButton roundedButtonequal;
        private RoundedButton roundedButtonaddition;
        private RoundedButton roundedButtonsubtraction;
        private RoundedButton roundedButtonmultiplication;
        private RoundedButton roundedButtondivision;
    }
}

