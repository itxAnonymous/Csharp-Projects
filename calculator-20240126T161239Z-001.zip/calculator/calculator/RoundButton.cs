﻿using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

public class RoundedButton : Button
{
    private int borderRadius = 10; // Adjust the border radius as needed
    private Color textColor = Color.White; // Default text color
    public int BorderRadius
    {
        get { return borderRadius; }
        set
        {
            if (value >= 0)
            {
                borderRadius = value;
                Invalidate();
            }
        }
    }
    public Color TextColor
    {
        get { return textColor; }
        set
        {
            textColor = value;
            Invalidate();
        }
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);

        GraphicsPath path = new GraphicsPath();
        int diameter = 2 * borderRadius;
        RectangleF bounds = new RectangleF(0, 0, Width - 1, Height - 1);

        path.AddArc(bounds.X, bounds.Y, diameter, diameter, 180, 90);
        path.AddArc(bounds.X + bounds.Width - diameter, bounds.Y, diameter, diameter, 270, 90);
        path.AddArc(bounds.X + bounds.Width - diameter, bounds.Y + bounds.Height - diameter, diameter, diameter, 0, 90);
        path.AddArc(bounds.X, bounds.Y + bounds.Height - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();

        Region = new Region(path);

        using (var brush = new SolidBrush(BackColor))
        {
            e.Graphics.FillPath(brush, path);
        }

        using (var pen = new Pen(BackColor, BorderRadius))
        {
            e.Graphics.DrawPath(pen, path);
        }
        using (var textBrush = new SolidBrush(textColor))
        {
            TextRenderer.DrawText(e.Graphics, Text, Font, ClientRectangle, textColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
        }
    }
}
