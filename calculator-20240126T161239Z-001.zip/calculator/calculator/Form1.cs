﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

       
        private List<double> numbers = new List<double>();
        private List<string> operators = new List<string>();

        private void roundedButton1_Click(object sender, EventArgs e)
        {


        }

        private void roundedButton10_Click(object sender, EventArgs e)
        {

        }

        private void AddNumber(string number)
        {
            textBox1.Text = textBox1.Text + number;
        }

        private void AddOperator(string op)
        {
            textBox1.Text = textBox1.Text + " " + op + " ";
        }

        private void PerformCalculation()
        {
            string[] inputs = textBox1.Text.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            if (inputs.Length % 2 == 0)
            {
                MessageBox.Show("Invalid input format.");
                return;
            }

            numbers.Clear();
            operators.Clear();

            foreach (string input in inputs)
            {
                if (double.TryParse(input, out double num))
                {
                    numbers.Add(num);
                }
                else
                {
                    operators.Add(input);
                }
            }

            double result = numbers[0];

            for (int i = 0; i < operators.Count; i++)
            {
                string op = operators[i];
                double nextNum = numbers[i + 1];

                switch (op)
                {
                    case "+":
                        result = result + nextNum;
                        break;
                    case "-":
                        result = result - nextNum;
                        break;
                    case "X":
                        result = result * nextNum;
                        break;
                    case "/":
                        if (nextNum == 0)
                        {
                            MessageBox.Show("Cannot divide by zero.");
                            return;
                        }
                        result = result / nextNum;
                        break;
                }
            }

            textBox1.Text = result.ToString();
        }

        private void roundedButtonone_Click(object sender, EventArgs e)
        {
            AddNumber("1");
        }
        private void roundedButtontwo_Click(object sender, EventArgs e)
        {
            AddNumber("2");

        }
        private void roundedButtonthree_Click(object sender, EventArgs e)
        {
            AddNumber("3");
        }
        private void roundedButtonfour_Click(object sender, EventArgs e)
        {
            AddNumber("4");
        }
        private void roundedButtonfive_Click(object sender, EventArgs e)
        {
            AddNumber("5");
        }
        private void roundedButtonsix_Click(object sender, EventArgs e)
        {
            AddNumber("6");
        }
        private void roundedButtonsevsen_Click(object sender, EventArgs e)
        {
            AddNumber("7");
        }
        private void roundedButtoneight_Click(object sender, EventArgs e)
        {
            AddNumber("8");
        }
        private void roundedButtonnine_Click(object sender, EventArgs e)
        {
            AddNumber("9");
        }
        private void roundedButtonzero_Click(object sender, EventArgs e)
        {
            AddNumber("0");
        }
        private void roundedButtondot_Click(object sender, EventArgs e)
        {
            AddNumber(".");

        }
       
        private void roundedButtonaddition_Click(object sender, EventArgs e)
        {
            AddOperator("+");
        }
        private void roundedButtonsubtraction_Click(object sender, EventArgs e)
        {
            AddOperator("-");
        }

        private void roundedButtonmultiplication_Click(object sender, EventArgs e)
        {
            AddOperator("X");
        }

        private void roundedButtondivision_Click(object sender, EventArgs e)
        {
            AddOperator("/");
        }

        private void roundedButtonequal_Click(object sender, EventArgs e)
        {
            PerformCalculation();
        }

        private void roundedButtonAC_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            numbers.Clear();
            operators.Clear();
        }

        private void roundedButtoncut_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox1.Text))
            {
                textBox1.Text = textBox1.Text.Substring(0, textBox1.Text.Length - 1);
            }
        }

        private void roundedButtonpercent_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Invalid input for percentage calculation.");
                return;
            }

            if (double.TryParse(textBox1.Text, out double num))
            {
                double percentage = num / 100;
                textBox1.Text = percentage.ToString();
            }
            else
            {
                MessageBox.Show("Invalid input for percentage calculation.");
            }
        }
    }
}







